CMF - AMQP - Configuration
=======


Directories:
- ssl:  tools for setting up a certificate authority, server and client certs.