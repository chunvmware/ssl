Securing Cluster nodes via Erlang SSL Distribution
- You can't, at least I haven't figured it out.
- process.