module.exports = {
	host: "localhost",
	port: 5673,
	vhost: "/",
	login: "guest",
	password: "guest",
	publishingInterval: 50
};