#!/bin/bash

rm -R ca
rm -R server
rm -R client